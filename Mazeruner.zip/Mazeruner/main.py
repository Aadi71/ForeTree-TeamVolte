import pygame
import random
import math
from pygame import mixer
import time

pygame.init()
limit = 0
Life=9

##Player##
player = pygame.image.load('frame.png')
pX = 50
pY = 55
pvel = 8

incor=mixer.Sound('incorrect.wav')
incor.set_volume(0.4)



##Blocks##
blocks = []
bX = []
bY = []
for i in range(0, 528):
    blocks.append(pygame.image.load('block.png'))
point=0
beeps=0

##Initialisation##
win = pygame.display.set_mode((1440, 720))
pygame.display.set_caption('Energy Maze')
icon = pygame.image.load('foretreelogo.png')
pygame.display.set_icon(icon)
background = pygame.image.load('background.jpg')
mixer.music.load('beckgrnd.wav')
mixer.music.set_volume(0.3)
mixer.music.play(-1)
levl = True


##Question Blocks Init#
quesblock1 = pygame.image.load('question block.png')
quesblock2 = pygame.image.load('question block.png')
quesblock3 = pygame.image.load('question block.png')
quesblock4 = pygame.image.load('question block.png')
quesblock5 = pygame.image.load('question block.png')
quesblock6 = pygame.image.load('question block.png')
qblocks = []
qblocks.append(quesblock1)
qblocks.append(quesblock2)
qblocks.append(quesblock3)
qblocks.append(quesblock4)
qblocks.append(quesblock5)
qblocks.append(quesblock6)
qX=[]
qY=[]

##Finish Line##
fini=pygame.image.load('finishline.png')
finix=0
finiy=0

##Final Line collision(¬‿¬)##
##Question block collision##
def qcollis(X, Y, X2, Y2):
    dis = distance(X, Y, X2, Y2)
    if dis <= 22:
        return True

##Player Movement##
def move():
    global pY,pX, pvel
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        pX -= pvel
        for i in range(0, limit):
            sst = collision(bX[i], bY[i], pX, pY)
            if sst:
                pX += 8
            # else:
            # fstep.play()

    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        pX += pvel
        for i in range(0, limit):
            sst = collision(bX[i], bY[i], pX, pY)
            if sst:
                pX -= 8
            # else:
            # fstep.play()

    if keys[pygame.K_UP] or keys[pygame.K_w]:
        pY -= pvel
        for i in range(0, limit):
            sst = collision(bX[i], bY[i], pX, pY)
            if sst:
                pY += 8
            # else:
            # fstep.play()

    if keys[pygame.K_DOWN] or keys[pygame.K_s]:
        pY += pvel
        for i in range(0, limit):
            sst = collision(bX[i], bY[i], pX, pY)
            if sst:
                pY -= 8
            # else:
            # fstep.play()


##Finish Block Code##
def finis():
    global pvel,beeps
    pvel = 0
    time.sleep(1.3)
    finiscreen = pygame.image.load('Compl.jpg')
    win.blit(finiscreen, (0, 0))
    font=pygame.font.Font('StalinistOne-Regular.ttf',60)
    font_big=pygame.font.Font('StalinistOne-Regular.ttf',80)
    victext=font_big.render("Congratulations",True,(255, 77, 77))
    victext2 = font.render("You did it", True, (255, 77, 77))
    win.blit(victext,(160,100))
    win.blit(victext2,(500,290))
    quit2()
    ss = mixer.Sound('Vic.wav')
    ss.set_volume(0.4)
    mixer.music.stop()
    if beeps == 0:
        ss.play()
    beeps =1
##Question Block 1##
def buttonq1_1():
    global levl, Life
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 22)
    cor = font.render("Mining", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(400,370,125,30))
    win.blit(cor,(400, 368))
    if click[0]==1:
        if 400+127 >mouse[0] >400 and 370+33>mouse[1]>370:
            levl=True
            Life -= 1
            incor.play()

def buttonq1_2():
    global levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    wro1 = font.render("Hydroelectric", True, (255, 255, 255))
    wro2 = font.render("development", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (700, 370, 255, 40))
    win.blit(wro1, (702, 368))
    win.blit(wro2, (702, 385))
    if click[0] == 1:
        if 700 + 257 > mouse[0] > 650 and 370 + 42 > mouse[1] > 370:
            levl = True

def q1():
    global levl
    levl = False
    font = pygame.font.Font('Roboto-Bold.ttf', 50)
    pygame.draw.rect(win, (153, 204, 255), (200, 100, 950, 500))
    gotext = font.render("  Which of the following is not ", True, (144, 16, 42))
    gotext2 = font.render(" a major cause of deforestation?", True, (144, 16, 42))
    win.blit(gotext, (300, 200))
    win.blit(gotext2,(300,250))
    buttonq1_1()
    buttonq1_2()

##Question Block 2##
def buttonq2_1():
    global levl, Life
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    corre = font.render("  Carbon", True, (255, 255, 255))
    corre2 = font.render("Monoxide", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(300,370,200,50))
    win.blit(corre,(308, 368))
    win.blit(corre2,(308,390))
    if click[0]==1:
        if 300+200 >mouse[0] >300 and 370+54>mouse[1]>370:
            levl=True


def buttonq2_2():
    global levl,Life
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    wro = font.render("Sunlight", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (900, 370, 200,50))
    win.blit(wro, (920, 384))
    if click[0] == 1:
        if 900 + 203 > mouse[0] > 800 and 370 + 53 > mouse[1] > 370:
            levl = True
            Life -= 1
            incor.play()

def q2():
    global levl
    levl = False
    pygame.draw.rect(win, (153, 204, 255), (150, 100, 1180, 500))
    font = pygame.font.Font('Roboto-Bold.ttf', 50)
    gotext = font.render("           Which among the following is not", True, (144, 16, 42))
    gotext2 = font.render("required for the formation of Photochemical smog?", True,(144, 16, 42))
    win.blit(gotext, (200, 200))
    win.blit(gotext2, (200,252))
    buttonq2_1()
    buttonq2_2()

##Question Block 3##
def buttonq3_1():
    global levl, Life
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    wrong = font.render("Atmospheric", True, (255, 255, 255))
    wrong2 = font.render("  Pollutants", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(400,370,230,46))
    win.blit(wrong,(400, 368))
    win.blit(wrong2,(400,388))

    if click[0]==1:
        if 400+230 >mouse[0] >300 and 370+46>mouse[1]>370:
            levl=True
            Life -= 0.5
            incor.play()

def buttonq3_2():
    global levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    correct = font.render("Sewage Water", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (700, 370, 264, 24))
    win.blit(correct, (702, 368))
    if click[0] == 1:
        if 700 + 264 > mouse[0] > 700 and 370 + 30 > mouse[1] > 370:
            levl = True

def q3():
    global levl
    levl = False
    pygame.draw.rect(win, (153, 204, 255), (200, 100, 950, 500))
    font = pygame.font.Font('Roboto-Bold.ttf', 50)
    gotext = font.render("The main source of water pollution is: ", True, (144, 16, 42))
    win.blit(gotext, (250, 200))
    buttonq3_1()
    buttonq3_2()

##Question Block 4##
def buttonq4_1():
    global levl, Life
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    corre = font.render("84%", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(400,370,90,30))
    win.blit(corre,(402, 372))
    if click[0]==1:
        if 400+94 >mouse[0] >400 and 370+33>mouse[1]>370:
            levl=True


def buttonq4_2():
    global levl,Life
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    incorre = font.render("50%", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (800, 370, 90, 30))
    win.blit(incorre, (802, 372))
    if click[0] == 1:
        if 800 + 94 > mouse[0] > 800 and 370 + 30 > mouse[1] > 370:
            levl = True
            Life -= 0.5
            incor.play()

def q4():
    global levl
    levl = False
    pygame.draw.rect(win, (153, 204, 255), (200, 100, 1000, 500))
    font = pygame.font.Font('Roboto-Bold.ttf', 50)
    gotext = font.render("How Much of the Typical Household's", True, (144, 16, 42))
    gotext2 = font.render("      Garbage Could Be Recycled?", True, (144, 16, 42))
    win.blit(gotext, (290, 200))
    win.blit(gotext2,(300,251))
    buttonq4_1()
    buttonq4_2()

##Question Block 5##
def buttonq5_1():
    global levl, Life
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    wro = font.render("5-6 Years", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(400,370,189,30))
    win.blit(wro,(404, 370))
    if click[0]==1:
        if 400+190 >mouse[0] >400 and 370+33>mouse[1]>370:
            levl=True
            Life -= 1

def buttonq5_2():
    global levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    correc = font.render("1-2 Years", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (700, 370, 185, 30))
    win.blit(correc, (704, 370))
    if click[0] == 1:
        if 700 + 189 > mouse[0] > 700 and 370 + 33 > mouse[1] > 370:
            levl = True

def q5():
    global levl
    levl = False
    pygame.draw.rect(win, (153, 204, 255), (200, 100, 950, 500))
    font = pygame.font.Font('Roboto-Bold.ttf', 40)
    gotext = font.render("It's Estimated that Air Pollution ", True, (144, 16, 42))
    gotext2 = font.render(" Shortens the Average Lifespan By: ", True, (144, 16, 42))
    win.blit(gotext, (290, 200))
    win.blit(gotext2,(300,242))
    buttonq5_1()
    buttonq5_2()

##Question Block 6##
def buttonq6_1():
    global levl, Life
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    incorr = font.render("50%", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(370,370,90,30))
    win.blit(incorr,(372, 370))
    if click[0]==1:
        if 370+94 >mouse[0] >370 and 370+33>mouse[1]>370:
            levl=True
            Life -= 1
            incor.play()

def buttonq6_2():
    global levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    corr = font.render("75% ", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (750, 370, 90, 30))
    win.blit(corr, (752, 372))
    if click[0] == 1:
        if 750 + 94 > mouse[0] > 750 and 370 + 30 > mouse[1] > 370:
            levl = True

def q6():
    global levl
    levl = False
    pygame.draw.rect(win, (153, 204, 255), (200, 100, 950, 500))
    font = pygame.font.Font('Roboto-Bold.ttf', 40)
    gotext = font.render("On Average, how much electricity can be saved from ", True, (144, 16, 42))
    gotext2 = font.render("    changing incandescent light bulbs to CFLs? ", True, (144, 16, 42))
    win.blit(gotext, (250,140))
    win.blit(gotext2, (250,195))
    buttonq6_1()
    buttonq6_2()

##Question Block 7#
def buttonq7_1():
    global levl, Life
    down=pygame.MOUSEBUTTONDOWN
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    incorr = font.render("2", True, (255, 255, 255))
    pygame.draw.rect(win,(255, 71, 26),(400,370,100,30))
    win.blit(incorr,(433, 372))
    if click[0]==1:
        if 400+265 >mouse[0] >400 and 370+33>mouse[1]>370:
            levl=True
            Life -= 1
            incor.play()

def buttonq7_2():
    global levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    corr = font.render("3", True, (255, 255, 255))
    pygame.draw.rect(win, (255, 71, 26), (750, 370, 100, 30))
    win.blit(corr, (783, 372))
    if click[0] == 1:
        if 750 + 100 > mouse[0] > 650 and 370 + 30 > mouse[1] > 370:
            levl = True

def q7():
    global levl
    levl = False
    pygame.draw.rect(win, (153, 204, 255), (200, 100, 950, 500))
    font = pygame.font.Font('Roboto-Bold.ttf', 40)
    gotext = font.render("How many Gallons of Water are wasted when you", True, (144, 16, 42))
    gotext2 = font.render("brush your teeth without turning off the faucet?", True,(144, 16, 42))
    win.blit(gotext, (260, 144))
    win.blit(gotext2, (260,184))
    buttonq7_1()
    buttonq7_2()

##Retry Button##
def retry():
    global Life,point, pX,pY,pvel,levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    rettext = font.render("Retry?", True, (0,0,0))
    pygame.draw.rect(win, (255, 255, 255), (750, 500, 140, 24))
    win.blit(rettext, (752, 501))
    if click[0] == 1:
        if 750 + 145 > mouse[0] > 750 and 500 + 30 > mouse[1] > 500:
            pX=50
            pY=55
            pvel=8
            Life=9
            levl=True
            mixer.music.play(-1)


##Quit Button##
def quit():
    global Life,point, pX,pY,pvel,levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 20)
    quittext = font.render("Quit", True, (0,0,0))
    pygame.draw.rect(win, (255, 255, 255), (450, 500, 90, 24))
    win.blit(quittext, (457, 497))
    if click[0] == 1:
        if 450 + 100 > mouse[0] > 450 and 500 + 30 > mouse[1] > 500:
            pygame.quit()

def quit2():
    global Life,point, pX,pY,pvel,levl
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    font = pygame.font.Font('StalinistOne-Regular.ttf', 60)
    quittext = font.render("Quit", True, (0,0,0))
    pygame.draw.rect(win, (255, 255, 255), (635, 500, 250, 64))
    win.blit(quittext, (645, 487))
    if click[0] == 1:
        if 635 + 250 > mouse[0] > 635 and 500 + 66 > mouse[1] > 500:
            pygame.quit()


##Game Over##
def GameOver():
    global point
    pvel = 0
    gover=pygame.image.load('GameOverscreen.jpeg')
    win.blit(gover,(100, 10))
    retry()
    quit()
    #time.sleep(2)
    ss=mixer.Sound('fail-trombone-01.wav')
    ss.set_volume(0.4)
    mixer.music.stop()
    if point==0:
        ss.play()
    point=1




##Maze Creation##
def meze(bx, by):
    global limit, finix, finiy
    limit = 0
    M = 33
    N = 16
    maze = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1,
            1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1,
            1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1,
            1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1,
            1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1,
            1, 2, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1,
            1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1,
            1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1,
            1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 3,
            1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1,
            1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1,
            1, 0, 0, 0, 0, 0, 2, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
            1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, ]
    counterblock = 0
    counterques = 0
    for i in range(0, M * N):
        if maze[bx + (by * M)] == 1:
            win.blit(blocks[counterblock], (bx * 44, by * 44))
            bX.append(bx * 44)
            bY.append(by * 44)
            counterblock += 1
            limit += 1
        if maze[bx + (by * M)] == 2:
            win.blit(qblocks[counterques], (bx * 44, by * 44))
            qX.append(bx * 44)
            qY.append(by * 44)
        if maze[bx + (by * M)] == 3:
            win.blit(fini, (bx * 44, by * 44))
            finix=bx*44
            finiy=by*44

        bx += 1
        if bx > M - 1:
            bx = 0
            by = by + 1


##Collision##
def collision(X, Y, X2, Y2):
    dis = distance(X, Y, X2, Y2)
    if dis <= 25:
        return True


##Pos##
#def pos_show(x, y, n):
 #   font = pygame.font.Font('Roboto-Medium.ttf', n)
  #  pxdisp = font.render("PX= " + str(pX), True, (16, 198, 198))
  #  pydisp = font.render("PY= " + str(pY), True, (16, 198, 198))
  #  win.blit(pxdisp, (x, y))
   # win.blit(pydisp, (x, y + 20))

##Life System##
def lifesys(x,y,n):
    global Life
    font = pygame.font.Font('StalinistOne-Regular.ttf',n)
    l = pygame.image.load('Heart.png')
    pdisp = font.render("Lives: ",True, (16, 198, 198))
    win.blit(pdisp, (x,y))
    for i in range (int(Life/3)):
        win.blit(l,(x+110+(i*25),y+5))




##distance calculater##
def distance(x1, y1, x2, y2):
    distance = math.sqrt(math.pow(x2 - x1, 2) + math.pow(y2 - y1, 2))
    return distance


##defining block##
blockX = 0
blockY = 0



##game loop##
leng=len(qblocks)
run = True
lives = 3
while run:
    win.fill((0, 0, 0))
    win.blit(background, (0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    meze(0, 0)
    ##player Limits##
    if pX <= 10:
        pX = 10
    if pX >= 1420:
        pX = 1420
    if pY <= 15:
        pY = 15
    if pY >= 680:
        pY = 680
    win.blit(player, (pX, pY))
    check = qcollis(pX, pY, finix, finiy)
    checkq1=qcollis(pX, pY, qX[0], qY[0])
    checkq2 = qcollis(pX, pY, qX[1], qY[1])
    checkq3 = qcollis(pX, pY, qX[2], qY[2])
    checkq4 = qcollis(pX, pY, qX[3], qY[3])
    checkq5 = qcollis(pX, pY, qX[4], qY[4])
    checkq6 = qcollis(pX, pY, qX[5], qY[5])
    checkq7 = qcollis(pX, pY, qX[6], qY[6])
    if checkq1:
        q1()
    elif checkq2:
        q2()
    elif checkq3:
        q3()
    elif checkq4:
        q4()
    elif checkq5:
        q5()

    elif checkq6:
        q6()
    elif checkq7:
        q7()

    if check:
        finis()


    # fstep = mixer.Sound()
    if levl:
        move()

    if Life <=1:
        GameOver()
    #pos_show(20, 20, 20)
    lifesys(10,10,20)
    pygame.display.update()
pygame.quit()
quit()